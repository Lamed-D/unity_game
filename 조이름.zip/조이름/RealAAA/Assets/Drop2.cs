﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Drop2 : MonoBehaviour, IDropHandler
{
    public Text Text;
    public void OnDrop(PointerEventData eventData)
    {

        Drag.draggedItem.transform.SetParent(this.transform);
    }

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
