﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemUI : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        //UI
        if (Input.GetKeyDown("p"))
        {
            foreach (Transform child in transform)
            {
                Debug.Log(child.name);
            }
        }

    }
}
