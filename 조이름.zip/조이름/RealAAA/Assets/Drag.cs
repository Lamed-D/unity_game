﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Drag : MonoBehaviour , IDragHandler, IBeginDragHandler , IEndDragHandler
{
    private Transform inventory;
    private Transform _startParent;
    public static GameObject draggedItem;
    // Use this for initialization
    void Start()
    {
        inventory = GameObject.Find("Inventory").transform;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnDrag(PointerEventData eventData)
    {
        this.transform.position = Input.mousePosition;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        draggedItem = this.gameObject;
        _startParent = transform.parent;
        //GetComponent<CanvasGroup>().blocksRaycasts = false;
        this.transform.SetParent(inventory);
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        draggedItem = null;
        if(transform.parent.name == "Inventory")
        {
            transform.SetParent(_startParent);
        }
        transform.localPosition = Vector3.zero;
        //GetComponent<CanvasGroup>().blocksRaycasts = true;
    }
}
