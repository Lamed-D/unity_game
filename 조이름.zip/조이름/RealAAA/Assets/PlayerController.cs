﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{

    [SerializeField] float speed = 1.0f;
    [SerializeField] float jumpForce = 4.0f;
    [SerializeField] public float damage;

    private float inputX;
    private Animator animator;
    private Rigidbody2D body2d;
    private bool combatIdle = false;
    private bool isGrounded = true;
    private float defalutspeed;
    public bool isDash;
    public float dashspeed;
    public float defalutTime;
    private float dashTime;
    public float dashcooltime;
    public float attackdelay;
    bool toggle = false;
    public GameObject[] UI;

    // Use this for initialization
    void Start()
    {
        defalutspeed = speed;
        animator = GetComponent<Animator>();
        body2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        // -- Handle input and movement --
        inputX = Input.GetAxis("Horizontal");

        // Swap direction of sprite depending on walk direction
        if (inputX > 0)
            transform.localScale = new Vector3(-1.0f, 1.0f, 1.0f);
        else if (inputX < 0)
            transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);

        // Move
        body2d.velocity = new Vector2(inputX * defalutspeed, body2d.velocity.y);

        if (Input.GetKeyDown(KeyCode.LeftShift))
            defalutspeed = 6;
        else
            defalutspeed = speed;

        if (Input.GetKeyDown(KeyCode.Z))
            isDash = true;

        if (dashTime <= 0)
        {
            defalutspeed = speed;
            if (isDash && dashcooltime <= 0)
            {
                dashcooltime = 2f;
                dashTime = defalutTime;
            }
        }
        else
        {
            dashTime -= Time.deltaTime;
            defalutspeed = dashspeed;
        }

        if (dashcooltime > 0)
            dashcooltime -= Time.deltaTime;

        isDash = false;

        // -- Handle Animations --
        isGrounded = IsGrounded();
        animator.SetBool("Grounded", isGrounded);

        //Death
        if (Input.GetKeyDown("k"))
            animator.SetTrigger("Death");
        //Hurt
        else if (Input.GetKeyDown("h"))
            animator.SetTrigger("Hurt");
        //Recover
        else if (Input.GetKeyDown("r"))
            animator.SetTrigger("Recover");
        //Change between idle and combat idle
        else if (Input.GetKeyDown("i"))
            combatIdle = !combatIdle;


        //UI
        if (Input.GetKeyDown("i"))
        {
            if (toggle) toggle = false;
            else toggle = true;
            for (int i = 0; i < 4; i++)
            {
                UI[i].SetActive(toggle);
            }
        }




        ////Attack (구 근접공격)
        //else if (Input.GetKeyDown(KeyCode.Q) && attackdelay <= 0)
        //{
        //    attackdelay = 1f;
        //    animator.SetTrigger("Attack");
        //    Collider2D[] hitEnemies = Physics2D.OverlapBoxAll(attackPoint.position, boxSize, 0);
        //    float damage = 20f;
        //    foreach (Collider2D col in hitEnemies)
        //    {
        //        if (col.tag == "enemy")
        //        {
        //            col.GetComponent<EnemyController>().TakeDamage(damage);
        //        }
        //    }
        //}

        if (attackdelay > 0)
        {
            attackdelay -= Time.deltaTime;
        }

        //Jump
        else if (Input.GetKeyDown("space") && isGrounded)
        {
            animator.SetTrigger("Jump");
            body2d.velocity = new Vector2(body2d.velocity.x, jumpForce);
        }

        //Walk
        else if (Mathf.Abs(inputX) > Mathf.Epsilon && isGrounded)
            animator.SetInteger("AnimState", 2);
        //Combat idle
        else if (combatIdle)
            animator.SetInteger("AnimState", 1);
        //Idle
        else
            animator.SetInteger("AnimState", 0);
    }

    bool IsGrounded()
    {
        return Physics2D.Raycast(transform.position, -Vector3.up, 0.03f);
    }
}
