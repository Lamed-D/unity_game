﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagiaController : MonoBehaviour {

    public float speed = 2f;
    public Vector3 position;
    public Vector3 targetPos;
    // Use this for initialization
    void Start () {
}
	
	// Update is called once per frame
	void Update ()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPos, Time.deltaTime * speed);
        if (transform.position == targetPos)
            Destroy(this.gameObject);
    }

    public void SetValue(Vector3 position2, Vector3 targetPos2)
    {
        position = position2;
        targetPos = targetPos2;
    }

    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    if (collision.gameObject.tag == "enemy")
    //    {
    //        collision.gameObject.GetComponent<EnemyController>().TakeDamage(35f);
    //    }
    //}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "enemy")
        {
            collision.gameObject.GetComponent<EnemyController>().TakeDamage(35f);
            Destroy(this.gameObject);
        }
    }
}
