﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class manabar : MonoBehaviour
{

    public Slider myhmanaar;

    // Use this for initialization
    void Start()
    {
        myhmanaar.value = 100;

    }

    // Update is called once per frame
    void Update()
    {

        //myhpbar.value -= 1;
    }
    public void heal()
    {
        myhmanaar.value = 100;
    }

    public void damage()
    {
        myhmanaar.value -= 1;
    }
}
