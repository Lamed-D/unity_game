﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicAttack : MonoBehaviour {

    public GameObject Magia;
    Vector3 mousePos, transPos, targetPos;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetMouseButtonDown(0))
        {
            mousePos = Input.mousePosition;
            transPos = Camera.main.ScreenToWorldPoint(mousePos);
            targetPos = new Vector3(transPos.x, transPos.y, 0);
            Vector3 position = transform.position;
            GameObject go = Instantiate(Magia) as GameObject;
            Vector3 positon = this.transform.position;
            position.y += 0.2f;
            go.transform.position = position;
            //go.SendMessage("Move");
            go.GetComponent<MagiaController>().SetValue(position, targetPos);
            //goController.Move(targetPos)
        }
    }

}

//using System.Collections.Generic; 참고소스
//using UnityEngine;

//public class MoveToClick : MonoBehaviour
//{
//    [SerializeField] float speed = 10f;
//    Vector3 mousePos, transPos, targetPos;

//    void Update()
//    {
//        if (Input.GetMouseButtonDown(0))
//            CalTargetPos();

//        MoveToTarget();
//    }

//    void CalTargetPos()
//    {
//        mousePos = Input.mousePosition;
//        transPos = Camera.main.ScreenToWorldPoint(mousePos);
//        targetPos = new Vector3(transPos.x, transPos.y, 0);
//    }

//    void MoveToTarget()
//    {
//        transform.position = Vector3.MoveTowards(transform.position, targetPos, Time.deltaTime * speed);
//    }
//}