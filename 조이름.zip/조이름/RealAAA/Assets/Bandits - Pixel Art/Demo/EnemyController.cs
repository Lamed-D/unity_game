﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    public float Health;
    // Use this for initialization
    void Start () {
        Health = 100f;
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void TakeDamage(float damage)
    {
        //체력이 damage만큼 까지게 합니다.
        Health -= damage;
        //체력이 0이하로 내려가면 게임 오브젝트를 파괴합니다.
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
