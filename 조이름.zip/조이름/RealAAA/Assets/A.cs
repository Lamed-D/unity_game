﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class A : MonoBehaviour {
    
    public Text text;
    // Use this for initialization
    void Start ()
    {
        
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    //Test클릭용
    public void onclicked()
    {
        GameObject TestItem = GameObject.Find("Test");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void death()
    {
        GameObject TestItem = GameObject.Find("death");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void devil()
    {
        GameObject TestItem = GameObject.Find("devil");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }


    public void fool()
    {
        GameObject TestItem = GameObject.Find("fool");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void magician()
    {
        GameObject TestItem = GameObject.Find("magician");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void star()
    {
        GameObject TestItem = GameObject.Find("star");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void sunmoon()
    {
        GameObject TestItem = GameObject.Find("sunmoon");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void theworld()
    {
        GameObject TestItem = GameObject.Find("theworld");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void emperor()
    {
        GameObject TestItem = GameObject.Find("emperor");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void hermit()
    {
        GameObject TestItem = GameObject.Find("hermit");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }

    public void hierophant()
    {
        GameObject TestItem = GameObject.Find("hierophant");
        GameObject Image = GameObject.Find("GameObject");
        Image.GetComponent<Image>().sprite = TestItem.GetComponent<Image>().sprite;
        text.text = "설명1";
    }
}
