﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hpbar : MonoBehaviour {

    public Slider myhpbar;

	// Use this for initialization
	void Start () {
        myhpbar.value = 100;

    }
	
	// Update is called once per frame
	void Update () {

        //myhpbar.value -= 1;
    }
    public void heal()
    {
        myhpbar.value = 100;
    }

    public void damage()
    {
        myhpbar.value -= 1;
    }
}
